mode d'emploi du jeu d'anagrammes:
1) lancer le serveur: serveur port
2)lancer le client: client IPserveur port
3) le client doit s'identifier (adresse IP et num de port)
4) le jeu commence, il faut trouver les anagrammes des mots proposés,
 ou taper FIN pour quitter le jeu. Le jeu s'arrête lorsque le joueur
 atteint 5 points.